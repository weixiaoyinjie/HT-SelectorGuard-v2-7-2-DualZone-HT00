# HT ScorePath Guard v3.0 — 半场正确比分路径、守单与人工提前结算提醒

本工程基于原 `HTFourPointAlerts` 四点提醒 App 与 `HT ScoreGuard v2.2` 继续升级，是**完整独立的 Android APK 项目**。不覆盖旧版。

## 主要设计原则

**目标是否可达 → 达到比分后是否能保持 → 是否需要核查真实提前结算报价 → 用户手动决定是否结算。**
比赛时间是达成和守住比分的条件之一，**不是40或42分钟强制退出指令**。

### 逐场设置2张或3张

- 在已选择的每场比赛旁，选择 **2张（主单+保险1）** 或 **3张（主单+保险1+保险2）**。
- 单独录入每张上半场比分（**主队-客队**）、投入金额、平台当前手动结算金额、是否已手动结算。空白比分不参与分析。
- 通过 OCR 导入筛选比赛截图后，直接点击该比赛旁的主单/保险单设置入口；API fixture ID 会校验。
- **如果某张已手动结算，下一球路径分析会将它排除**，防止系统误以为仍有保险单。

### 预警的优先级

1. **比分是否达到**：逐单区分 HIT / PENDING / BROKEN / CLOSED；待达单还需主队、客队各进多少球；通过可用的真实短窗数据，评估所需进球方是否出现有效攻势。只有持续进攻的证据标签，**不会编造进球概率**。
2. **比分命中能否保持**：当前比分任一方的下一球都可能使准确比分单失效；同时显示“主队再进一球”和“客队再进一球”时，哪一张其他保险单可能接力命中。这里只分析**下一球**，不代表之后两球、三球的所有路径已被覆盖。
3. **守分威胁**：当前比分阶段最近1–2/3/5/10分钟可用的射门增量、射正、禁区射门、xG（*仅API确实提供*）与红牌；比分更正、进球、红牌重置旧趋势。数据不足显示 UNKNOWN，不把累计射门当作最新威胁，也不把“暂无机会”等同于“保证守住”。
4. **提前结算**：提醒用户打开平台检查是否存在真实 Cash Out 报价，输入后按**整组所有有效单**测算手动结算后的总盈亏。平台报价可能随时改变/暂停；**本 App 不登录、不自动读取、不自动点击、不保证可以结算**。
5. **时间因素**：分析待达所需进球数与剩余常规上半场分钟数；45分钟以后补时未知。时间只调整可达性/守分风险解释，不自动做结算决策。
6. **人工确认**：重要守分危险提醒在未确认且监控仍运行时最多重复两次；“已查看”按钮停止这次重复，未来新风险仍单独提醒。
7. **AI API 二次复核**：足球 API 是比分和射门等的事实源，本地规则立即预警；OpenAI API 可选，异步复核**目标能否到达、命中能否守住、下一球保险承接、数据不足和人工结算**，不能编造新赛事事实。AI 并非第二家独立足球实时数据源。

### 四个原有定点提醒绝不改动

- **开赛、15分钟、30分钟、40分钟**各发一次数据通知，包含当时比分、射门/xG（如果存在）及可用的3/5/10分钟增量。
- **进球 / 红牌 / 可达性和守分风险**属于额外事件提醒；40分钟只提示复核，不强制退场。

## 独立安装标识

- 这个 v3.0 APK：`com.htlive.monitor.scorepathguard`（显示名 `HT ScorePath 预警`）
- v2.2 ScoreGuard：`com.htlive.monitor.scoreguard`
- 原四点提醒版：`com.htlive.monitor.checkpoints`

三者可以共存。首次安装新包需重新填 API Key、筛选比赛和仓位；不同应用的数据互不共享。请勿把任何 API Key 直接写进源码或上传 GitHub。

## GitHub 新仓库 / 一键编译

本次交付的是 **新仓库准备文件**，并不等于已替用户在线创建 GitHub 仓库。

1. 打开 <https://github.com/new>，创建全新的空仓库，比如 `HTScorePathGuard-Android`；建议 Private。
2. 在新仓库根目录上传 **`HTScorePathGuard_OneUpload.zip`**，不要先改名；此压缩包包含所有源码和测试。
3. 创建文件 **`.github/workflows/build-apk.yml`**（把随附的 `HTScorePathGuard_build-apk.yml` 内容复制进去）。
4. 点击 **Actions → Build HT ScorePath Guard APK → Run workflow**；完成后下载工件 `HTScorePathGuard-debug-apk`，里面是 `app-debug.apk`。
5. 安装，允许通知，配置 API Key。打开比赛监控，选择每场2/3张单，保存比分后启用监控。

若不是“上传ZIP”而是把源码解压直接上传 GitHub，需要相应去掉 workflow 的 unzip 步骤。本工作流按「根目录 ZIP + workflow」流程编写。

⚠️ **当前环境没有 Android SDK/Gradle，本地只完成了 Java 决策引擎测试、HTML/JS 测试、工作流文件检查；不代表真实 Android APK 编译、通知延迟和平台结算已在手机通过测试**。

## 重要的事实边界与公开资料

- API-FOOTBALL 的 `/fixtures` 用于比分与状态；`/fixtures/statistics` 负责射门等；`/fixtures/events` 用于红牌/进球/VAR。官方标注比分端点更新频率约15秒、统计约1分钟，但实际赛事覆盖与延迟有差异，建议调用频率也有额度限制。**xG 不是该统计接口承诺的标准必有字段**。https://www.api-football.com/documentation-v3
- 研究提示应将比分阶段分段，控制球队实力、比赛时间、领先落后以及红牌影响；实时进攻统计对预测的贡献有限，不能宣称“命中概率准确”。https://www.nature.com/articles/s41598-021-03157-3 和 https://www.sciencedirect.com/science/article/pii/S0169207025001025
- bet365 阿根廷 Cash Out 条件说明：提前结算需当前显示报价，遇赔率变化/市场暂停可能无法成功。https://extra.bet365.bet.ar/features/es/cash-out
- Android 15+ 的 `dataSync` 前台服务有**24小时累计6小时限制**，以及通知权限、电池优化等实际限制，不保证全天不间断后台服务。https://developer.android.com/about/versions/15/behavior-changes-15

## 测试

```
for t in tests/*.test.js; do node "$t"; done
mkdir -p /tmp/ht-guard-test
javac -encoding UTF-8 -d /tmp/ht-guard-test \
 tests/java/org/json/JSONObject.java tests/java/org/json/JSONArray.java \
 app/src/main/java/com/htlive/monitor/ScoreGuardEngine.java \
 tests/java/com/htlive/monitor/ScoreGuardEngineTest.java \
 tests/java/com/htlive/monitor/ScorePathTest.java
java -cp /tmp/ht-guard-test com.htlive.monitor.ScoreGuardEngineTest
java -cp /tmp/ht-guard-test com.htlive.monitor.ScorePathTest
```

`tests/java/org/json/` 仅作脱离 Android 的算法测试替身，**不会**打入最终APK。复盘记录与金额留在本机；送给 AI 的只有本场比分、目标比分和非金额数据快照。
