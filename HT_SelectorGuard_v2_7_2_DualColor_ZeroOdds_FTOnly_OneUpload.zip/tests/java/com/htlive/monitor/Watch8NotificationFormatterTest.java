package com.htlive.monitor;
import org.json.JSONObject;
import org.json.JSONArray;
public final class Watch8NotificationFormatterTest {
  static void check(boolean b,String msg){if(!b)throw new AssertionError(msg);}
  static JSONObject fixture() {
    JSONObject x=new JSONObject().put("home","曼彻斯特联队").put("away","切尔西").put("h","1").put("a","0").put("minute",36);
    JSONArray items=new JSONArray().put(new JSONObject().put("pick","1-0"));
    x.put("guardRisk",new JSONObject().put("level","HIGH").put("items",items).put("hit",1).put("pending",1).put("broken",0));
    return x;
  }
  public static void main(String[] args){
    JSONObject m=fixture();
    Watch8NotificationFormatter.Message risk=Watch8NotificationFormatter.format("🛡 守分风险 · 核查结算",m,System.currentTimeMillis(),"");
    check(risk.title.contains("1-0"),"risk score missing");
    check(risk.expanded.contains("命中1 待达1 失效0"),"ticket states absent");
    check(risk.expanded.contains("高风险"),"risk action absent");
    check(!risk.expanded.contains("null"),"null displayed");
    check(risk.expanded.split("\\n").length<=3,"more than 3 body lines");
    check(!risk.timed,"risk mistaken for checkpoint");
    Watch8NotificationFormatter.Message mark=Watch8NotificationFormatter.format("第15分钟定点复核 · 非强制结算",m,System.currentTimeMillis(),"");
    check(mark.timed,"checkpoint not classified");
    check(mark.title.contains("15'"),"checkpoint mark absent");
    check(mark.expanded.contains("现36'"),"late delivery minute hidden");
    check(mark.expanded.contains("统计缺失或滞后"),"stale statistics shown as fresh");
    check(mark.expanded.split("\\n").length<=3,"checkpoint too long");
    Watch8NotificationFormatter.Message minute3=Watch8NotificationFormatter.format("⏱ 第3分钟 · 预警监控已启动",m,System.currentTimeMillis(),"");
    check(minute3.timed,"3rd minute not a timed alert");
    check(minute3.title.contains("3'启动"),"3rd minute not prominent on watch");
    Watch8NotificationFormatter.Message delayed=Watch8NotificationFormatter.format("⚠ 第3分钟启动提醒延迟",m,System.currentTimeMillis(),"");
    check(delayed.title.contains("延迟") && delayed.preview.contains("延迟"),"delayed startup not distinguished on watch");
    Watch8NotificationFormatter.Message red=Watch8NotificationFormatter.format("🟥 红牌 · 比赛人数变化",m,System.currentTimeMillis(),"红牌增加");
    check(red.title.contains("红牌"),"red card not prominent");
    Watch8NotificationFormatter.Message missing=Watch8NotificationFormatter.format("⚽ 进球",null,System.currentTimeMillis(),"");
    check(missing.title.contains("?-?"),"missing data wrongly reported as score");
    check(!Watch8NotificationFormatter.isTimed("⚽ 进球"),"goal marked timed");
    System.out.println("Watch8 notification formatting OK");
  }
}
