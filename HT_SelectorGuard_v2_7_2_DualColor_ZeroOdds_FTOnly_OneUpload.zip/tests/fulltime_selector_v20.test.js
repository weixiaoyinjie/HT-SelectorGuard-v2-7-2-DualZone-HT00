'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const engine=require('../app/src/main/assets/fulltime_engine.js');
assert.equal(engine.COMBOS.length,4);
for(const c of engine.COMBOS){assert.equal(c.scores.length,3);assert.equal(new Set(c.scores).size,3);}
const date='2026-11-25T15:00:00+00:00';
function previous(i,team,home,score){
 const [h,a]=score;return {fixture:{id:10000+team*100+i,date:new Date(Date.parse(date)-(i+1)*86400e3).toISOString(),status:{short:'FT'}},league:{type:'League',name:'Premier League'},teams:{home:{id:home?team:900+i},away:{id:home?900+i:team}},score:{fulltime:{home:h,away:a}}};
}
const hs=Array.from({length:20},(_,i)=>previous(i,10,true,i%6===0?[1,0]:[2,0]));
const as=Array.from({length:20},(_,i)=>previous(i,20,false,i%4===0?[2,1]:[2,1]));
const fixture={fixture:{id:123,date,status:{short:'NS'}},teams:{home:{id:10},away:{id:20}},league:{type:'League',name:'Premier League'}};
function market(odds=true){return [{bookmakers:[{name:'Bet365',bets:[
{id:10,name:'Correct Score',values:['1-0','2-0','1-1','2-1','0-0'].map(x=>({value:x,odd: odds?'7.0':'3.0'}))},
{id:1,name:'Match Winner',values:[{value:'Home',odd:'1.9'},{value:'Draw',odd:'3.5'},{value:'Away',odd:'5'}]},
{id:2,name:'Goals Over/Under',values:[{value:'Over 3.5',odd:'5.0'},{value:'Under 3.5',odd:'1.2'}]}
]}]}];}
const good=engine.analyze({fixture,homeHistory:hs,awayHistory:as,oddsRows:market(),exactBetIds:[10]});
assert.equal(good.combo.items.length,3);
assert.equal(good.grade==='PASS',false,'qualified synthetic case should not be hard PASS: '+good.reason);
const noOdds=engine.analyze({fixture,homeHistory:hs,awayHistory:as,oddsRows:market(false),exactBetIds:[10]});
assert.equal(noOdds.canSelect,false);
assert.equal(noOdds.grade,'C');
const noHist=engine.analyze({fixture,homeHistory:[],awayHistory:[],oddsRows:market(),exactBetIds:[10]});
assert.equal(noHist.grade,'PASS');
const base=fs.readFileSync('app/src/main/java/com/htlive/monitor/MatchLifecycle.java','utf8');
assert.match(base,/"FT"\.equals\(period\)/);assert.match(base,/case "FT"/);assert.match(base,/"2H"\.equals\(status\)/);
const ui=fs.readFileSync('app/src/main/assets/selector.html','utf8');
for(const key of ['periodHT','periodFT','scanFull','renderFullResults','suggestedScores','selectedMatches()'])assert(ui.includes(key),key);
const monitor=fs.readFileSync('app/src/main/java/com/htlive/monitor/MonitorService.java','utf8');
assert(monitor.includes('SelectorMonitorSync.period(this,id)'));
assert(monitor.includes('MatchLifecycle.shouldPrune(status,period)'));
assert(monitor.includes('new int[]{60,75,85}'));
const wear=fs.readFileSync('wear/src/main/java/com/htlive/watch44/WearBrief.java','utf8');
assert(wear.includes('j.optString("period")'));
console.log('PASS: full time low-goal combos, fixture mode lock, 2H monitoring and Watch8 mode parity');
