package com.htlive.monitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.graphics.Color;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SelectorActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/selector.html";
    private static final int CREATE_DOCUMENT_REQUEST = 7331;
    private WebView webView;
    private AIRequestBridge aiRequestBridge;
    private byte[] pendingBytes;
    private boolean exactAlarmSettingsOpened=false;
    private final ExecutorService saveExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10,16,32));
        getWindow().setNavigationBarColor(Color.rgb(10,16,32));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(10,16,32));
        setContentView(webView);
        // Native WebView alert/confirm support is retained for general app messages.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(SelectorActivity.this)
                                        .setMessage(message)
                    .setPositiveButton("继续", (dialog, which) -> result.confirm())
                    .setNegativeButton("取消", (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(SelectorActivity.this)
                    .setMessage(message)
                    .setPositiveButton("确定", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.confirm())
                    .show();
                return true;
            }
        });

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true); // remember API Key in app-private WebView storage
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setSupportMultipleWindows(false);

        // Serve the packaged HTML on a trustworthy HTTPS origin; avoid file:// CORS issues.
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .setDomain(APP_HOST)
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target=request.getUrl();
                if ("https".equals(target.getScheme()) && APP_HOST.equals(target.getHost())) return false;
                if (!request.isForMainFrame()) return true;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, target));
                } catch (ActivityNotFoundException e) { showToast("无法打开外部链接"); }
                return true;
            }
        });
        // Expose only to our packaged page; no arbitrary remote documents load in the WebView.
        webView.addJavascriptInterface(new FileBridge(), "AndroidFile");
        webView.addJavascriptInterface(new MonitorBridge(), "AndroidMonitor");
        aiRequestBridge = new AIRequestBridge(webView);
        webView.addJavascriptInterface(aiRequestBridge, "AndroidAI");
        webView.loadUrl(APP_URL);
    }

    /** Only the selector screen can submit selections; content is validated again natively. */
    public final class MonitorBridge {
        @JavascriptInterface public String getKey(){
            return getSharedPreferences("ht_monitor",MODE_PRIVATE).getString("apiKey","");
        }
        @JavascriptInterface public String selectedIds(){return SelectorMonitorSync.selectedIds(SelectorActivity.this);}
        @JavascriptInterface public String selectedMatches(){return SelectorMonitorSync.selectorMatches(SelectorActivity.this);}
        @JavascriptInterface public String setSelected(String fixture,boolean checked,String key){
            String result=SelectorMonitorSync.setSelected(SelectorActivity.this,fixture,checked,key);
            if(checked && result.contains("\"ok\":true"))
                runOnUiThread(()->askExactAlarmOnce());
            return result;
        }
        @JavascriptInterface public String saveSnapshot(String mode, String json){
            try { SelectorSnapshotStore.save(getFilesDir(),mode,json); return "OK"; }
            catch(Exception e){ return "ERROR: " + (e.getMessage()==null?"无法保存候选":e.getMessage()); }
        }
        @JavascriptInterface public String loadSnapshot(String mode){
            try { return SelectorSnapshotStore.load(getFilesDir(),mode); }
            catch(Exception e){ return ""; }
        }
        @JavascriptInterface public String lastPageMode(){
            return getSharedPreferences("ht_monitor",MODE_PRIVATE).getString("selectorPageMode","HT");
        }
        @JavascriptInterface public void setPageMode(String mode){
            if("HT".equals(mode)||"FT".equals(mode))
                getSharedPreferences("ht_monitor",MODE_PRIVATE).edit().putString("selectorPageMode",mode).apply();
        }
        @JavascriptInterface public void openMonitor(){openMonitorForFixture("");}
        @JavascriptInterface public void openMonitorForFixture(String fixtureId){
            // Do not accept arbitrary navigation payloads from JavaScript.
            final String safeId=fixtureId!=null&&fixtureId.matches("[0-9]{1,12}")?fixtureId:"";
            runOnUiThread(()->{
                Intent intent=new Intent(SelectorActivity.this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                if(!safeId.isEmpty())intent.putExtra(MainActivity.EXTRA_FOCUS_FIXTURE,safeId);
                startActivity(intent);
            });
        }
    }

    /** Explicit optional user approval improves the +3m clock wake-up on Android 12+.
     * Without approval the app still keeps its inexact alarm/poll fallback. */
    private void askExactAlarmOnce(){
        if(Build.VERSION.SDK_INT<31)return;
        android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);
        if(am==null || am.canScheduleExactAlarms())return;
        android.content.SharedPreferences p=getSharedPreferences("ht_monitor",MODE_PRIVATE);
        if(p.getBoolean("selector_exact_alarm_prompted",false))return;
        p.edit().putBoolean("selector_exact_alarm_prompted",true).apply();
        new AlertDialog.Builder(this)
            .setTitle("加强第3分钟预警")
            .setMessage("Android可能推迟普通后台闹钟。可授权本应用使用精确闹钟，降低第3分钟提醒延迟；仍需网络、通知权限与有效实时赛况，无法保证零漏报。")
            .setPositiveButton("去设置",(d,w)->{
                try{
                    exactAlarmSettingsOpened=true;
                    startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:"+getPackageName())));
                }catch(Exception ex){exactAlarmSettingsOpened=false;showToast("请在系统设置中授权精确闹钟");}
            })
            .setNegativeButton("稍后",(d,w)->{})
            .show();
    }

    @Override protected void onResume(){
        super.onResume();
        // The monitor page can change the watchlist while this Activity is paused.
        if(webView!=null)webView.evaluateJavascript(
            "window.refreshSelectorMonitorState&&window.refreshSelectorMonitorState();",null);
        if(!exactAlarmSettingsOpened)return;
        exactAlarmSettingsOpened=false;
        // Rebuild alarms with the new authorization; older inexact alarms are cancelled.
        android.content.SharedPreferences p=getSharedPreferences("ht_monitor",MODE_PRIVATE);
        ReminderReceiver.schedule(this,p.getString("alarm_watch","[]"));
    }

    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    public final class FileBridge {
        @JavascriptInterface public void saveBase64(String fileName, String mimeType, String base64Body) {
            if (base64Body == null || base64Body.length() > 28_000_000) {
                showToast("文件太大，无法保存"); return;
            }
            String sanitized = fileName == null ? "HTScoreScanner.png" : fileName.replaceAll("[^0-9a-zA-Z._() 一-龥-]", "_");
            if (sanitized.isEmpty()) sanitized="HTScoreScanner.png";
            final String name=sanitized;
            final String mime = mimeType != null && mimeType.toLowerCase(Locale.ROOT).startsWith("image/png") ? "image/png"
                : mimeType != null && mimeType.toLowerCase(Locale.ROOT).startsWith("text/csv") ? "text/csv"
                : "application/octet-stream";
            saveExecutor.execute(() -> {
                try {
                    byte[] bytes=Base64.decode(base64Body, Base64.DEFAULT);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveMediaStore(name,mime,bytes);
                    else runOnUiThread(() -> selectDocument(name,mime,bytes));
                } catch(Exception e) { showToast("保存失败：" + e.getMessage()); }
            });
        }
    }

    private void saveMediaStore(String name, String mime, byte[] bytes) throws IOException {
        boolean image=mime.startsWith("image/");
        Uri collection=image ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        ContentValues values=new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
        values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,(image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS)+"/HTScoreScanner");
        values.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri uri=getContentResolver().insert(collection,values);
        if(uri==null) throw new IOException("未能创建文件");
        try {
            try(OutputStream os=getContentResolver().openOutputStream(uri)) {
                if(os==null) throw new IOException("无法写入文件");
                os.write(bytes);
            }
            ContentValues done=new ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(uri,done,null,null);
            showToast(image ? "图片已保存到相册 Pictures/HTScoreScanner" : "文件已保存到 Downloads/HTScoreScanner");
        } catch(IOException e) {
            getContentResolver().delete(uri,null,null);
            throw e;
        }
    }

    // Android 8-9: use system document picker, avoiding broad storage permissions.
    private void selectDocument(String name, String mime, byte[] bytes) {
        pendingBytes=bytes;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE,name);
        try { startActivityForResult(intent,CREATE_DOCUMENT_REQUEST); }
        catch(ActivityNotFoundException e) { pendingBytes=null; showToast("系统没有文件保存程序"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=CREATE_DOCUMENT_REQUEST) return;
        byte[] bytes=pendingBytes; pendingBytes=null;
        Uri uri=data==null?null:data.getData();
        if(resultCode!=RESULT_OK||uri==null||bytes==null) return;
        saveExecutor.execute(() -> {
            try(OutputStream os=getContentResolver().openOutputStream(uri)) {
                if(os==null) throw new IOException("无法创建输出流");
                os.write(bytes); showToast("文件已保存");
            }catch(Exception e){showToast("保存失败："+e.getMessage());}
        });
    }

    @Override public void onBackPressed() {
        if(webView!=null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onPause() {
        if(webView!=null)webView.evaluateJavascript(
            "window.saveSelectorSnapshot&&window.saveSelectorSnapshot();",null);
        super.onPause();
    }
    @Override protected void onDestroy() {
        if(aiRequestBridge!=null) aiRequestBridge.shutdown();
        if(webView!=null){ webView.removeJavascriptInterface("AndroidFile"); webView.removeJavascriptInterface("AndroidAI"); webView.removeJavascriptInterface("AndroidMonitor"); webView.destroy(); }
        saveExecutor.shutdown();
        super.onDestroy();
    }
}
