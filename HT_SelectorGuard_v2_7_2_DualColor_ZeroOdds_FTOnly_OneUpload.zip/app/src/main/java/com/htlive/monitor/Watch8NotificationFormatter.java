package com.htlive.monitor;

import org.json.JSONObject;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Compact, truthful Android-to-Wear-OS notification text. No prediction is invented. */
public final class Watch8NotificationFormatter {
    private Watch8NotificationFormatter() {}
    private static final Pattern MARK = Pattern.compile("第(3|15|30|40|60|75|85)分钟");

    public static final class Message {
        public final String title, preview, expanded;
        public final boolean timed;
        Message(String title, String preview, String expanded, boolean timed){
            this.title=title;this.preview=preview;this.expanded=expanded;this.timed=timed;
        }
    }

    public static boolean isTimed(String type){
        String t=type==null?"":type;
        return t.contains("比赛开始") || MARK.matcher(t).find();
    }
    private static String cut(String raw, int max){
        if(raw==null || raw.trim().isEmpty())return "?";
        String s=raw.trim().replaceAll("[\\r\\n\\t]+"," ");
        int count=s.codePointCount(0,s.length());
        if(count<=max)return s;
        return s.substring(0,s.offsetByCodePoints(0,max-1))+"…";
    }
    private static String score(JSONObject m){
        if(m==null)return "?-?";
        return cut(m.optString("h","?"),3)+"-"+cut(m.optString("a","?"),3);
    }
    private static String teams(JSONObject m){
        if(m==null)return "比赛数据待核实";
        return cut(m.optString("home","主队"),7)+"-"+cut(m.optString("away","客队"),7);
    }
    private static String kind(String type){
        String t=type==null?"":type;
        if(t.contains("模拟") || t.contains("演示"))return "🧪 演示";
        if(t.contains("未确认"))return "🔔 未确认";
        if(t.contains("红牌"))return "🟥 红牌";
        if(t.contains("比分更正") || t.contains("VAR"))return "🔄 比分更正";
        if(t.contains("全部比分单失效"))return "⛔ 全部失效";
        if(t.contains("进球" ) && !t.contains("所需进球方"))return "⚽ 进球";
        if(t.contains("比分命中"))return "🎯 已命中";
        if(t.contains("守分"))return "🛡 守分预警";
        if(t.contains("攻势"))return "📈 待达攻势";
        return "🔔 比分预警";
    }
    private static String states(JSONObject risk){
        if(risk==null)return "";
        if(risk.optJSONArray("items")==null || risk.optJSONArray("items").length()==0)return "";
        return "命中"+risk.optInt("hit",0)+" 待达"+risk.optInt("pending",0)+" 失效"+risk.optInt("broken",0);
    }
    private static String statValue(JSONObject obj,String key){
        if(obj==null || !obj.has(key) || obj.isNull(key))return "—";
        return cut(obj.optString(key,"—"),5);
    }
    private static String stats(JSONObject m,long now){
        if(m==null)return "统计未取得";
        JSONObject st=m.optJSONObject("stats");
        long statAt=m.optLong("lastStatsAt",0L);
        if(st==null || !st.optBoolean("available",false) || statAt<=0 ||
                now-statAt>90_000L || now-statAt< -90_000L)return "统计缺失或滞后";
        JSONObject home=st.optJSONObject("home"),away=st.optJSONObject("away");
        String out="射正"+statValue(home,"on")+"/"+statValue(away,"on");
        if(home!=null && away!=null && home.has("xg") && away.has("xg") &&
                !home.isNull("xg") && !away.isNull("xg")){
            out+=" xG"+statValue(home,"xg")+"/"+statValue(away,"xg");
        }
        return out;
    }
    private static String action(String type,JSONObject risk,boolean timed){
        String t=type==null?"":type;
        if(t.contains("模拟") || t.contains("演示"))return "演示消息，非真实预警";
        if(t.contains("红牌"))return "红牌变化｜核对双方人数";
        if(t.contains("比分更正") || t.contains("VAR"))return "比分更正｜重新核对单据";
        if(t.contains("全部比分单失效"))return "目标失效｜核查剩余单据";
        if(t.contains("进球") && !t.contains("所需进球方"))return "进球后重新核对比分路径";
        if(t.contains("未确认"))return "风险未确认｜请复核";
        String level=risk==null?"":risk.optString("level","");
        if("HIGH".equals(level))return "高风险｜检查平台结算报价";
        if("WATCH".equals(level))return "风险升高｜检查结算报价";
        if("BROKEN".equals(level))return "目标已失效｜核对单据";
        if("UNKNOWN".equals(level))return "数据不足｜不能判断安全";
        if(t.contains("命中"))return "比分命中｜观察下一球";
        if(t.contains("攻势"))return "所需进球方出现攻势";
        if(t.contains("第3分钟启动提醒延迟"))return "启动延迟｜立即核查赛况";
        if(t.contains("第3分钟"))return "已启动监控｜注意数据延迟";
        if(timed)return "定点复核，非自动结算";
        return "实时复核｜不可保证结果";
    }
    public static Message format(String type,JSONObject match,long receivedAt,String fallback){
        String t=type==null?"":type;
        boolean timed=isTimed(t);
        Matcher matcher=MARK.matcher(t);
        String name;
        if(timed){
            name=t.contains("第3分钟启动提醒延迟")?"⚠ 3'启动延迟":
                matcher.find()?"⏱ "+matcher.group(1)+"'"+("3".equals(matcher.group(1))?"启动":"复核"):"⏱ 开赛复核";
        }else{name=kind(t);}
        int minute=match==null?-1:match.optInt("minute",-1);
        String title=name+" "+score(match);
        JSONObject risk=match==null?null:match.optJSONObject("guardRisk");
        String teams=teams(match);
        String state=states(risk);
        String note=action(t,risk,timed);
        String evidence=timed?stats(match,receivedAt):"";
        // Fixed checkpoints can arrive late due to Doze/network delays. Show the observed match minute.
        String observation=minute>=0?"现"+minute+"' ":"";
        String middle=observation+teams;
        String lower=timed?evidence:state;
        String ending=note;
        if(timed && !state.isEmpty()){
            // The fourth line is omitted to avoid Wear OS vertical overflow.
            ending=state;
            if(evidence.startsWith("统计缺失"))ending="统计滞后｜"+state;
        }
        String expanded=middle+"\n"+(!lower.isEmpty()?lower+"\n":"")+ending;
        String preview=observation+teams+"｜"+(t.contains("第3分钟启动提醒延迟")?"启动延迟，立即核查":timed?evidence:note);
        // Keep the collapsed message glanceable; the watch controls actual line wrapping.
        preview=cut(preview,43);
        return new Message(title,preview,expanded,timed);
    }
}
